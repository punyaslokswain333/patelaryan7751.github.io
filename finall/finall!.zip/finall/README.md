Sliding Panels Template
=========

A simple portfolio template, with project preview images that slide out to reveal the selected project.

[Article on CodyHouse](http://codyhouse.co/gem/sliding-panels-template/)

[Demo](https://codyhouse.co/demo/sliding-panels-template/index.html)
 
[Terms](http://codyhouse.co/terms/)

Images: [Unsplash](https://unsplash.com/)